#include<stdio.h>

int a=0,b=0;
int N,K,W;
double ans;

double dfs(int score){
	if(score>=K){
		return 1.0*(score<=N);
	}
	else{
		int i=W;
		double tmp=0;
		for(;i;i--)
			tmp+=1.0/W*dfs(score+i);
	}
	return tmp;
}
//智商不够，看不懂dp，就用系统栈来凑（逃
//答案肯定对，系统栈也不会溢出，但是必然Time Limit Exceed

int main(){
	scanf("%d%d%d",&N,&K,&W);
	ans=dfs(0);
	printf("%lf",ans);
}
