#include<stdio.h>
using namespace std;

int main(){
	int n,k,w;
	double dp[20005]={0};
	// dp[x] is the probability of scoring below N when alice has a total score of x.
	double s=0;
	scanf("%d%d%d",&n,&k,&w);
	for(int i=k;i<k+w;i++){ // from k to k+w-1
		dp[i]=(i<=n);
		// When x>=k, if x>N then dp[x]=0, oppositely, if x<=N then dp[x]=1.
		s+=dp[i];
		// s is the sum of the elements in the set { dp[x+1] , ... , dp[x+w] }
		// Here x starts from k-1
	}
	for(int i=k-1;i>=0;i--){
			dp[i]=s/w;
			// apparently, when x<k, dp[x]=( dp[x+1]/w + ... + dp[x+w]/w )
			s+=dp[i]-dp[i+w];
			// push in the head 
			// kick the tail 
	}
	printf("%lf",dp[0]);
	// the final result is dp[0]
}
//Theoretically, the complexity (time/memory) is O(K+W).