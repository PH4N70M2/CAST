package com.bit.web.controller;

import com.bit.web.bean.Result;
import com.bit.web.bean.User;
import com.bit.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping(value = "/register")
    public String register(User user) {
        Result result = userService.register(user);
        if (result.getMsg().equals("Exist User")) {
            return "redirect:/existed";
        }
        if (result.getMsg().equals("Success")) {
            return "redirect:/umain?ss=" + user.getUsernamess();
        }
        return result.getDetail().toString();
    }

    @PostMapping(value = "/login")
    public String login(User user) {
        Result result = userService.login(user);
        if (result.getMsg().equals("Success")) {
            return "redirect:/umain?ss=" + user.getUsernamess();
        }
        if (result.getMsg().equals("psd")) {
            return "redirect:/psd";
        }
        return result.getDetail().toString();
    }

    @PostMapping(value = "/update")
    public String update(User user) {
        Result result = userService.update(user);
        if (result.getMsg().equals("Success")) {
            return "redirect:/umain?ss=" + result.getSs();
        }
        return result.getDetail().toString();
    }

    @PostMapping(value = "/delete")
    public String delete(User user) {
        Result result = userService.delete(user);
        if (result.getMsg().equals("Success")) {
            return "redirect:/";
        }
        return result.getDetail().toString();
    }
}
