package com.bit.web.mapper;

import com.bit.web.bean.User;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Mapper
@Repository
public interface UserMapper {

    @Select(value = "select u.username,u.password from MyUsers u where u.username=#{username}")
    @Results({@Result(property = "username", column = "username"), @Result(property = "password", column = "password")})
    User findUserByName(@Param("username") String username);


    @Select("select * from MyUsers where usernamess = #{ss}")
    User findUserDetailBySS(@Param("ss") String ss);


    @Insert("INSERT INTO MyUsers (id, username, password, email, usernamess) VALUE (#{id},#{username},#{password},#{email},#{usernamess})")
    @Options(useGeneratedKeys = true, keyProperty = "id", keyColumn = "id")
    void register(User user);

    @Select("select * from MyUsers where username = #{username} and password = #{password}")
    User login(User user);

    @Delete("DELETE FROM MyUsers WHERE username = #{username} and password = #{password}")
    void delete(User user);


    @Update("UPDATE MyUsers SET password = #{password} WHERE username = #{username} and password=#{OldPassword}")
    void update(User user);


}
