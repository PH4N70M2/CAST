package com.bit.web.bean;

public class User {

    private Long id;
    private String username;
    private String password;
    private String email;
    private String usernamess;
    private String OldPassword;

    public String getOldPassword() {
        return OldPassword;
    }

    public void setOldPassword(String oldPassword) {
        OldPassword = oldPassword;
    }

    public String getUsernamess() {
        return usernamess;
    }

    public void setUsernamess(String usernamess) {
        this.usernamess = usernamess;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


}

