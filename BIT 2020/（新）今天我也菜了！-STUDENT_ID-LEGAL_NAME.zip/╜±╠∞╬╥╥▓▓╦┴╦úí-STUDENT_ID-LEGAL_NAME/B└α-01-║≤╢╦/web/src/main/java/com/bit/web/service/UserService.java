package com.bit.web.service;

import com.bit.web.bean.Result;
import com.bit.web.bean.User;
import com.bit.web.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;

@Service
@Transactional(rollbackFor = RuntimeException.class)
public class UserService {

    @Autowired
    private UserMapper userMapper;

    public Result register(User user) {
        Result result = new Result();
        result.setSuccess(false);
        result.setDetail(null);
        try {
            User existUser = userMapper.findUserByName(user.getUsername());
            if (existUser != null) {
                result.setMsg("Exist User");
            } else {
                String md5pass = DigestUtils.md5DigestAsHex(user.getPassword().getBytes());
                user.setPassword(md5pass);
                user.setUsernamess(DigestUtils.md5DigestAsHex(user.getUsername().getBytes()));
                userMapper.register(user);
                result.setMsg("Success");
                result.setSuccess(true);
                result.setDetail(user);
            }

        } catch (Exception e) {
            result.setMsg(e.getMessage());
            e.printStackTrace();
        }
        return result;
    }


    public Result login(User user) {
        Result result = new Result();
        result.setSuccess(false);
        result.setDetail(null);
        try {
            String md5pass = DigestUtils.md5DigestAsHex(user.getPassword().getBytes());
            user.setPassword(md5pass);
            User user0 = userMapper.login(user);
            if (user0.getId() == null) {
                result.setMsg("psd");
            } else {
                result.setMsg("success");
                result.setSuccess(true);
                result.setDetail(user);
                result.setSs(user0.getUsernamess());
            }
        } catch (Exception e) {
            result.setMsg(e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

    public Result update(User user) {
        Result result = new Result();
        result.setSuccess(false);
        result.setDetail(null);
        try{
            user.setPassword(DigestUtils.md5DigestAsHex(user.getPassword().getBytes()));
            user.setOldPassword(DigestUtils.md5DigestAsHex(user.getPassword().getBytes()));
            userMapper.update(user);
            result.setMsg("Success");
            result.setSuccess(true);
            result.setDetail(user);
        } catch(Exception e) {
            result.setMsg(e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

    public Result delete(User user) {
        Result result = new Result();
        result.setSuccess(false);
        result.setDetail(null);
        try{
            user.setPassword(DigestUtils.md5DigestAsHex(user.getPassword().getBytes()));
            userMapper.delete(user);
            result.setMsg("Success");
            result.setSuccess(true);
            result.setDetail(user);
        } catch(Exception e) {
            result.setMsg(e.getMessage());
            e.printStackTrace();
        }
        return result;
    }
}
