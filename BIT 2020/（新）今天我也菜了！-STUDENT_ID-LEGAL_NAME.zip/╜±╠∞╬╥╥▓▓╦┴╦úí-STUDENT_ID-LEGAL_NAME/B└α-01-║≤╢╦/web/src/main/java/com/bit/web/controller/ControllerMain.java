package com.bit.web.controller;

import com.bit.web.bean.User;
import com.bit.web.mapper.UserMapper;
import com.bit.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping
public class ControllerMain {

    @Autowired
    public UserMapper userMapper;

    @GetMapping("/umain")
    public String uMain(@RequestParam(name = "ss", required = true, defaultValue = "") String ss, Model model) {
        User user = userMapper.findUserDetailBySS(ss);
        model.addAttribute("email",user.getEmail());
        model.addAttribute("username",user.getUsername());
        return "umain";
    }

    @GetMapping("/psd")
    public String psd(Model model) {
        return "psd";
    }
    @GetMapping("/existed")
    public String uMain(Model model) {
        return "existed";
    }
}
