package com.bit.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class HelloController {
    @GetMapping("/hello")
    public String hello(@RequestParam(name = "name", required = false, defaultValue = "游客") String name, Model model) {
        model.addAttribute("name", name);
        return "index";
    }

    @GetMapping("/login")
    public String login(Model model) {
        return "log_in";
    }

    @GetMapping("/register")
    public String register(Model model) {
        return "sign_up";
    }

    @GetMapping("/update")
    public String update(@RequestParam(name = "username", required = true, defaultValue = "123") String username, Model model) {
        model.addAttribute("username", username);
        return "update_";
    }

    @GetMapping("/delete")
    public String delete(@RequestParam(name = "username", required = true, defaultValue = "123") String username, Model model) {
        model.addAttribute("username", username);
        return "delete_";
    }

//    @GetMapping("/Ulist")
//    public String Ulist(Model model) {
//
//    }
}
