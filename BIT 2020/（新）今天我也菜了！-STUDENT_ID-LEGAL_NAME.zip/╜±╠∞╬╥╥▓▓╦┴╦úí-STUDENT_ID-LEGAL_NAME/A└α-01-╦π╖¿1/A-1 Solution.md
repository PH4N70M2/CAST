# A-1 Solution

As the description goes, the original text only includes common English words along with some punctuations, and the password is a set of 3 English characters. ***Therefore, I listed all the possibilities and compared them with the requirements. For details, see my code "getcipher.cpp".***

However, the data size is so huge that the program has to run a long period of time. ***So I picked out a smaller piece in the front of the cipher to shrink the scale, since a short string is enough to judge whether the text makes sense.***

Soon I found "`god`" is probably the password. However the decrypted part was not the same length as the raw data is. Anyway I chose it. 

I wrote another program "decrypt" to decrypt the cipher, then in the output I saw numbers. That's it, numbers are involved. Then everything makes sense*. And the original text is from Bible too, corresponding with the password.* (XD) Then I went back to add numbers to the judgement, this time it finally worked as expected.

***And then I went back to the additional description and saw numbers involved too. QAQ***

Not so difficult as I imagined, except for these incidents. (XD)



P.S. 

A space is expected to appear before the number 14 but it doesn't.



By Shen