//#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
int a[10000],b[10000];
int x=0;

void init(){	//input the data
	FILE* fp=fopen("cipher2.txt","r");
	while(fscanf(fp,"%d",a+x)!=EOF){
		x++;
	}
	fclose(fp);
}


int main(){

	memset(a,0,sizeof(a));
	init();

	FILE* fp=fopen("raw.txt","w");
	char p[4]="god";	// The password was found in the first part.

	for(int i=0;i<x;i++){
		b[i]=p[i%3]^a[i];	//xor
		fprintf(fp,"%c",b[i]);
	}

	fclose(fp);
}
