//#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
char ref[]=" 0123456789qwertyuiopasdfghjklzxcvbnnmQWERTYUIOPASDFGHJKLZXCVBNNM,.()";
// All the chars that can be involved 
// "rolling the keyboard in the deep" LOL
int a[10000],b[10000];
int x=0;

int isEN(int x){	//check the validity of the char 
	for(int y=0;ref[y];y++){
		if(x==ref[y])
			return y;
	}
	return -1;
}

void init(){
	FILE* fp=fopen("cipher1.txt","r");
	while(fscanf(fp,"%d",a+x)!=EOF){	// input cipher text
		x++;
	}
	fclose(fp);
}


int main(){

	memset(a,0,sizeof(a));
	init();

	FILE* fp=fopen("get.txt","w");

	fprintf(fp, "%d:", x);
	for(int i=0;i<x;i++)
		fprintf(fp, "%d ", a[i]);
	fprintf(fp, "\n\n");

	int p[3]={0,0,0};	// a strange and unnecessary initialization
	
	for(p[0]='a';p[0]<='z';p[0]++)
	{
		for(p[1]='a';p[1]<='z';p[1]++)
		{
			for(p[2]='a';p[2]<='z';p[2]++)	// list all possible passwords
			{
				int i;
				
				for(i=0;i<x;i++)
				{
					b[i]=p[i%3]^a[i];	// xor
					if(isEN(b[i])==-1)break;	// if invalid char appears, stop the sequence
				}
				
				if(i==x)	// if all chars are valid then output the sequence
				{
					fprintf(fp, "%c%c%c: ", p[0], p[1], p[2]);
					for(i=0;i<x;i++)
						fprintf(fp,"%c",b[i]);
					fprintf(fp,"\n\n");
				}
		
			}
		}
	}
	fclose(fp);
}
